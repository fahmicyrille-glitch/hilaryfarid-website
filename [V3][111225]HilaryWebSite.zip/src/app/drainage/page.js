"use client";

import { useEffect, useState } from "react";
import Script from "next/script";
import Image from "next/image";
import { FadeIn, SlideUp } from "@/components/MotionWrapper";
import DrainageGallery from "@/components/DrainageGallery";
import SEO from "@/components/SEO";
import MobileSummary from "@/components/MobileSummary";


const SECTIONS = [
  { id: "a-propos", label: "À propos du drainage" },
  { id: "avant-apres", label: "Avant / Après" },
  { id: "benefices", label: "Bénéfices au quotidien" },
  { id: "contre-indications", label: "Contre-indications" },
  { id: "galerie", label: "Galerie" },
  { id: "faq", label: "FAQ" },
];


export default function DrainagePage() {
  const [activeId, setActiveId] = useState("a-propos");
  const [showBackToTop, setShowBackToTop] = useState(false);

  /* ------------------ 1) Scrollspy avec IntersectionObserver ------------------ */
  useEffect(() => {
    if (typeof window === "undefined") return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            if (SECTIONS.some((s) => s.id === id)) {
              setActiveId(id);
            }
          }
        });
      },
      {
        root: null,
        threshold: 0.25,
        rootMargin: "-10% 0px -60% 0px",
      }
    );

    // Observer toutes les sections
    SECTIONS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    // SI on est en haut de la page → À propos actif
    const onScroll = () => {
      if (window.scrollY < 200) {
        setActiveId("a-propos");
      }
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  /* ------------------ 2) Bouton retour en haut ------------------ */
  useEffect(() => {
    if (typeof window === "undefined") return;

    const onScroll = () => {
      setShowBackToTop(window.scrollY > 600);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();

    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* ------------------ 3) Smooth scroll ------------------ */
  const handleSmoothScroll = (e, id) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (!el) return;

    const y = el.getBoundingClientRect().top + window.scrollY - 120;
    window.scrollTo({ top: y, behavior: "smooth" });
  };

  const handleBackToTop = () =>
    window.scrollTo({ top: 0, behavior: "smooth" });

  const smoothScroll = (e, id) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (!el) return;
    window.scrollTo({
      top: el.getBoundingClientRect().top + window.scrollY - 120,
      behavior: "smooth",
    });
  };


  return (
    <main>
      {/* ========= SCHEMA UNIQUE ========= */}
      <Script
        id="schema-drainage"
        type="application/ld+json"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(
            [
              {
                "@context": "https://schema.org",
                "@type": "MedicalWebPage",
                "@id": "https://www.hilaryfarid-osteopathe.fr/drainage#page",
                url: "https://www.hilaryfarid-osteopathe.fr/drainage",
                name: "Drainage lymphatique – Méthode Renata França",
                description:
                  "Drainage lymphatique méthode Renata França : dégonflement immédiat, ventre plat, jambes légères, amélioration de la circulation et détox rapide.",
                about: {
                  "@type": "TherapeuticProcedure",
                  name: "Drainage lymphatique Renata França",
                },
                breadcrumb: {
                  "@type": "BreadcrumbList",
                  itemListElement: [
                    {
                      "@type": "ListItem",
                      position: 1,
                      name: "Accueil",
                      item: "https://www.hilaryfarid-osteopathe.fr",
                    },
                    {
                      "@type": "ListItem",
                      position: 2,
                      name: "Drainage lymphatique",
                      item: "https://www.hilaryfarid-osteopathe.fr/drainage",
                    },
                  ],
                },
              },
              {
                "@context": "https://schema.org",
                "@type": "Service",
                "@id": "https://www.hilaryfarid-osteopathe.fr/drainage#service",
                serviceType: "Drainage lymphatique – Méthode Renata França",
                provider: {
                  "@type": "Person",
                  "@id": "https://www.hilaryfarid-osteopathe.fr#hilary-farid",
                },
                areaServed: ["Sèvres", "Paris 15"],
                description:
                  "Méthode Renata França : drainage lymphatique manuel tonique, résultats immédiats : dégonflement, ventre plat, jambes légères, silhouette affinée.",
                audience: ["Adult", "PostpartumWomen", "Athlete"],
              },
              {
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                "@id": "https://www.hilaryfarid-osteopathe.fr/sevres#business",
                name: "Cabinet d'Ostéopathie – Sèvres",
                telephone: "+33 6 72 01 45 39",
                logo: "https://www.hilaryfarid-osteopathe.fr/hilary-logo.svg",
                image:
                  "https://www.hilaryfarid-osteopathe.fr/cabinet-sevres/cabinet-sevres-1.webp",
                address: {
                  "@type": "PostalAddress",
                  streetAddress: "104 Grande Rue",
                  postalCode: "92310",
                  addressLocality: "Sèvres",
                  addressCountry: "FR",
                },
                makesOffer: {
                  "@type": "Service",
                  "@id":
                    "https://www.hilaryfarid-osteopathe.fr/drainage#service",
                },
              },
              {
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                "@id":
                  "https://www.hilaryfarid-osteopathe.fr/paris15#business",
                name: "Cabinet d'Ostéopathie – Paris 15",
                telephone: "+33 6 72 01 45 39",
                logo: "https://www.hilaryfarid-osteopathe.fr/hilary-logo.svg",
                image:
                  "https://www.hilaryfarid-osteopathe.fr/cabinet-paris15/cabinet-paris15-1.webp",
                address: {
                  "@type": "PostalAddress",
                  streetAddress: "28 Rue Letellier",
                  postalCode: "75015",
                  addressLocality: "Paris",
                  addressRegion: "Île-de-France",
                  addressCountry: "FR",
                },
                makesOffer: {
                  "@type": "Service",
                  "@id":
                    "https://www.hilaryfarid-osteopathe.fr/drainage#service",
                },
              },
              {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                mainEntity: [
                  {
                    "@type": "Question",
                    name:
                      "Quels sont les effets du drainage lymphatique Renata França ?",
                    acceptedAnswer: {
                      "@type": "Answer",
                      text:
                        "La méthode Renata França réduit la rétention d'eau, affine la silhouette, dégonfle dès la première séance, améliore la digestion et procure des jambes légères.",
                    },
                  },
                  {
                    "@type": "Question",
                    name: "Combien de séances sont nécessaires ?",
                    acceptedAnswer: {
                      "@type": "Answer",
                      text:
                        "Une séance suffit pour un effet immédiat. Une cure de 3 à 5 séances optimise les résultats.",
                    },
                  },
                  {
                    "@type": "Question",
                    name: "La méthode est-elle douloureuse ?",
                    acceptedAnswer: {
                      "@type": "Answer",
                      text:
                        "Non. Les pressions sont toniques mais jamais douloureuses, et toujours adaptées au confort du patient.",
                    },
                  },
                  {
                    "@type": "Question",
                    name: "Est-ce adapté en post-partum ?",
                    acceptedAnswer: {
                      "@type": "Answer",
                      text:
                        "Oui, c'est très efficace pour dégonfler, améliorer la digestion et retrouver une sensation de légèreté.",
                    },
                  },
                ],
              },
            ],
            null,
            2
          ),
        }}
      />

      {/* ================= HERO ================= */}
      <section className="relative h-[70vh] w-full overflow-visible">
        <Image
          src="/drainage/drainage_ventre.webp"
          alt="Drainage lymphatique Renata França"
          fill
          priority
          className="absolute inset-0 w-full h-full object-cover"
        />

        <div className="absolute inset-0 bg-black/50 flex flex-col justify-center text-center px-6">
          <FadeIn>
            <Image
              src="/drainage/drainage_Logo.webp"
              alt="Logo Renata França"
              width={160}
              height={160}
              className="mx-auto w-40 mb-6 opacity-90"
            />

            <h1 className="text-4xl md:text-5xl font-semibold text-white drop-shadow-lg">
              Drainage lymphatique <br />
              Méthode Renata França
            </h1>

            <p className="mt-4 text-offwhite text-lg md:text-xl max-w-2xl mx-auto">
              Une technique dynamique aux résultats <strong>immédiats</strong> :
              dégonflement, légèreté, détox, silhouette affinée.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* ================= WRAPPER SOMMAIRE + CONTENU ================= */}
      <section className="bg-offwhite py-12 px-4 md:px-6">
        <div className="max-w-6xl mx-auto flex gap-10 overflow-visible">
          {/* ===== SOMMAIRE STICKY (DESKTOP) ===== */}
          <aside className="hidden lg:block w-64 flex-shrink-0 sticky top-28 self-start h-max">
            <div className="bg-white rounded-2xl shadow-sm border border-light/70 p-5">
              <h2 className="text-sm font-semibold text-primary mb-3 tracking-wide uppercase">
                Sommaire
              </h2>

              <nav className="space-y-2 text-sm">
                {SECTIONS.map((section) => (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    onClick={(e) => handleSmoothScroll(e, section.id)}
                    className={`block rounded-lg px-3 py-2 transition ${
                      activeId === section.id
                        ? "bg-primary/10 text-primary font-semibold"
                        : "text-graywarm hover:text-primary hover:bg-light/70"
                    }`}
                  >
                    {section.label}
                  </a>
                ))}
              </nav>
            </div>
          </aside>

          {/* ===== CONTENU PRINCIPAL ===== */}
          <div className="flex-1 space-y-16">
            {/* ===== Sommaire Mobile ===== */}
            <MobileSummary
              sections={SECTIONS}
              activeId={activeId}
              smoothScroll={smoothScroll}
            />

            {/* ====================== SECTION : A PROPOS ======================= */}
            <SlideUp>
              <section
                id="a-propos"
                className="pt-24 bg-white rounded-2xl shadow-sm border border-light/70 p-6 md:p-8"
              >
                <h2 className="text-3xl md:text-4xl font-semibold text-primary text-center">
                  Un drainage unique, aux résultats immédiats
                </h2>

                <div className="mt-10 space-y-8 text-graywarm leading-relaxed text-base md:text-lg">
                  <p className="text-center">
                    Le <strong>drainage lymphatique Renata França</strong> est
                    une méthode révolutionnaire, bien plus tonique que le
                    drainage classique. Elle stimule intensément la circulation{" "}
                    <strong>lymphatique</strong> et <strong>sanguine</strong>{" "}
                    pour obtenir un effet visible dès la première séance.
                  </p>

                  <p className="text-center font-medium text-xl text-primary">
                    👉 Résultats immédiats : silhouette affinée, ventre
                    dégonflé, jambes légères, énergie retrouvée.
                  </p>

                  <hr className="border-graywarm/30 my-8" />

                  <div id="effets">
                    <h3 className="text-2xl font-semibold text-primary text-center">
                      Pourquoi cette méthode est-elle si efficace ?
                    </h3>

                    <ul className="mt-4 space-y-2 list-disc list-inside">
                      <li>Pressions profondes et rythmées</li>
                      <li>Circulation lymphatique relancée</li>
                      <li>Déstockage de l'eau stagnante</li>
                      <li>Détoxification naturelle du corps</li>
                    </ul>

                    <p className="mt-4 italic">
                      Une sensation incomparable de légèreté, dès la première
                      séance.
                    </p>
                  </div>

                  <hr className="border-graywarm/30 my-8" />

                  <div>
                    <h3 className="text-2xl font-semibold text-primary text-center">
                      Parfait avant un événement
                    </h3>

                    <p className="mt-3 text-center">
                      Idéal avant un <strong>shooting</strong>, un{" "}
                      <strong>mariage</strong>, des vacances, une compétition ou
                      un <strong>post-partum</strong>.
                    </p>
                  </div>

                  <hr className="border-graywarm/30 my-8" />

                  <div>
                    <h3 className="text-2xl font-semibold text-primary text-center">
                      Combien de séances ?
                    </h3>

                    <ul className="mt-4 space-y-2 list-inside">
                      <li>✔️ Une séance = effet immédiat</li>
                      <li>
                        ✔️ Cure de 3 à 5 séances = résultats optimisés
                      </li>
                    </ul>
                  </div>

                  <hr className="border-graywarm/30 my-8" />

                  <div>
                    <h3 className="text-2xl font-semibold text-primary text-center">
                      Une praticienne formée et certifiée
                    </h3>

                    <p className="mt-3 text-center">
                      Je suis <strong>formée et certifiée</strong> à la Méthode
                      Renata França, et j'adapte chaque séance à votre
                      morphologie.
                    </p>
                  </div>
                </div>
              </section>
            </SlideUp>

            {/* ====================== SECTION : AVANT APRES ==================== */}
            <SlideUp>
              <section
                id="avant-apres"
                className="bg-white rounded-2xl shadow-sm border border-light/70 p-6 md:p-8"
              >
                <h2 className="text-3xl font-semibold text-primary text-center">
                  Résultats Avant / Après
                </h2>

                <div className="grid md:grid-cols-2 gap-12 mt-12">
                  <div className="shadow-xl rounded-lg overflow-hidden">
                    <Image
                      src="/drainage/avant_apres_jambe.webp"
                      alt="Résultat avant après jambes drainage lymphatique"
                      width={900}
                      height={900}
                      sizes="(max-width: 768px) 100vw,
                             (max-width: 1200px) 50vw,
                             450px"
                      className="w-full h-auto"
                    />
                  </div>

                  <div className="shadow-xl rounded-lg overflow-hidden">
                    <Image
                      src="/drainage/avant_apres_ventre.webp"
                      alt="Résultat avant après ventre drainage lymphatique"
                      width={900}
                      height={900}
                      sizes="(max-width: 768px) 100vw,
                             (max-width: 1200px) 50vw,
                             450px"
                      className="w-full h-auto"
                    />
                  </div>
                </div>
              </section>
            </SlideUp>

            {/* ====================== SECTION : BENEFICES ====================== */}
            <SlideUp>
              <section
                id="benefices"
                className="bg-white rounded-2xl shadow-sm border border-light/70 p-6 md:p-8"
              >
                <h2 className="text-3xl font-semibold text-primary text-center">
                  Effets & bénéfices du drainage Renata França
                </h2>

                <div className="grid md:grid-cols-2 gap-10 mt-12 items-center">
                  <Image
                    src="/drainage/drainage_jambe.webp"
                    alt="Drainage lymphatique jambes méthode Renata França"
                    width={800}
                    height={800}
                    sizes="(max-width: 768px) 90vw,
                           (max-width: 1200px) 50vw,
                           400px"
                    className="rounded-lg shadow-lg"
                  />

                  <ul className="space-y-4 text-graywarm text-lg">
                    <li>✔️ Effet immédiat dès la première séance</li>
                    <li>✔️ Diminution de la rétention d'eau</li>
                    <li>✔️ Ventre plus plat & meilleure digestion</li>
                    <li>✔️ Jambes légères et affinées</li>
                    <li>✔️ Silhouette harmonisée & dégonflement rapide</li>
                    <li>✔️ Détox naturelle & sensation de légèreté</li>
                  </ul>
                </div>

              </section>
            </SlideUp>

            {/* ================= SECTION : CONTRE INDICATIONS ================= */}
            <SlideUp>
              <section
                id="contre-indications"
                className="bg-white rounded-2xl shadow-sm border border-light/70 p-6 md:p-8"
              >
                <h2 className="text-3xl font-semibold text-primary text-center">
                  Contre-indications & précautions
                </h2>

                <p className="mt-6 text-graywarm text-center max-w-2xl mx-auto">
                  Le drainage lymphatique Renata França est une méthode
                  puissante. Certaines situations demandent un avis médical
                  préalable :
                </p>

                <ul className="mt-6 space-y-3 text-graywarm list-disc list-inside">
                  <li>Insuffisance cardiaque ou rénale non stabilisée</li>
                  <li>Phlébite / thrombose récente</li>
                  <li>Infections aiguës, fièvre</li>
                  <li>Cancer en cours de traitement (avis médical obligatoire)</li>
                </ul>

                <p className="mt-6 text-graywarm text-center">
                  En cas de doute, je vous invite à me contacter avant la
                  séance.
                </p>
              </section>
            </SlideUp>

            {/* ====================== SECTION : GALERIE ======================== */}
            <SlideUp>
              <section
                id="galerie"
                className="bg-white rounded-2xl shadow-sm border border-light/70 p-6 md:p-8"
              >
                <h2 className="text-3xl font-semibold text-primary text-center mb-8">
                  Galerie du drainage Renata França
                </h2>

                <DrainageGallery />
              </section>
            </SlideUp>

            {/* ====================== SECTION : FAQ ============================ */}
            <SlideUp>
              <section
                id="faq"
                className="bg-white rounded-2xl shadow-sm border border-light/70 p-6 md:p-8"
              >
                <h2 className="text-3xl font-semibold text-primary text-center">
                  FAQ – Drainage lymphatique Renata França
                </h2>

                <div className="mt-10 space-y-6">
                  <details className="bg-offwhite/80 border rounded-xl p-4 shadow-sm">
                    <summary className="font-semibold text-primary cursor-pointer">
                      Quels sont les effets dès la première séance ?
                    </summary>
                    <p className="mt-2 text-graywarm text-sm">
                      Diminution de la rétention d'eau, ventre plus plat,
                      jambes légères, sensation de dégonflement immédiate.
                    </p>
                  </details>

                  <details className="bg-offwhite/80 border rounded-xl p-4 shadow-sm">
                    <summary className="font-semibold text-primary cursor-pointer">
                      Est-ce que la méthode est douloureuse ?
                    </summary>
                    <p className="mt-2 text-graywarm text-sm">
                      Non. La pression est tonique mais jamais douloureuse et
                      toujours adaptée à votre confort.
                    </p>
                  </details>

                  <details className="bg-offwhite/80 border rounded-xl p-4 shadow-sm">
                    <summary className="font-semibold text-primary cursor-pointer">
                      Combien de séances sont recommandées ?
                    </summary>
                    <p className="mt-2 text-graywarm text-sm">
                      Une séance suffit pour un effet immédiat. Une cure de 3 à
                      5 séances optimise les résultats.
                    </p>
                  </details>

                  <details className="bg-offwhite/80 border rounded-xl p-4 shadow-sm">
                    <summary className="font-semibold text-primary cursor-pointer">
                      Est-ce adapté en post-partum ?
                    </summary>
                    <p className="mt-2 text-graywarm text-sm">
                      Oui, très recommandé pour éliminer la rétention d'eau,
                      améliorer la digestion et réduire les gonflements.
                    </p>
                  </details>

                  <details className="bg-offwhite/80 border rounded-xl p-4 shadow-sm">
                    <summary className="font-semibold text-primary cursor-pointer">
                      Faut-il boire beaucoup d'eau après la séance ?
                    </summary>
                    <p className="mt-2 text-graywarm text-sm">
                      Oui, il est conseillé de bien s'hydrater pour accompagner
                      la détoxification naturelle.
                    </p>
                  </details>
                </div>
              </section>
            </SlideUp>

            {/* ====================== CTA FINAL =============================== */}
            <FadeIn>
              <section className="bg-primary text-offwhite rounded-2xl shadow-sm p-8 md:p-10 text-center">
                <h2 className="text-3xl font-semibold">
                  Réserver votre séance
                </h2>

                <p className="mt-3 text-offwhite/90">
                  Drainage lymphatique disponible à <strong>Sèvres</strong> et{" "}
                  <strong>Paris 15</strong>.
                </p>

                <a
                  href="https://www.doctolib.fr/osteopathe/sevres/hilary-farid/booking/places?specialityId=10"
                  target="_blank"
                  className="mt-6 inline-block bg-offwhite text-primary px-10 py-4 rounded-lg hover:bg-light transition"
                >
                  Réserver une séance
                </a>
              </section>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ===== Bouton retour en haut ===== */}
      {showBackToTop && (
        <button
          onClick={handleBackToTop}
          className="fixed bottom-6 right-4 md:right-6 z-40 bg-primary text-offwhite w-10 h-10 rounded-full shadow-lg flex items-center justify-center text-lg hover:bg-secondary transition"
          aria-label="Revenir en haut de la page"
        >
          ↑
        </button>
      )}
    </main>
  );
}
