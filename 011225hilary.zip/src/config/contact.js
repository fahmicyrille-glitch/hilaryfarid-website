// src/config/contact.js

export const PHONE = "06 72 01 45 39";
export const PHONE_LINK = "+33672014539"; // format utilisable dans les liens tel:

export const EMAIL = "hilaryfarid.osteopathe@gmail.com";
